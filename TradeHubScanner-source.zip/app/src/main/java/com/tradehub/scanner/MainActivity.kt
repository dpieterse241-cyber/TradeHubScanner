package com.tradehub.scanner

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.view.Gravity
import android.graphics.Color
import android.widget.Toast

class MainActivity : Activity() {
    private lateinit var info: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        requestNotificationPermission()

        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(36, 48, 36, 36)
            setBackgroundColor(Color.rgb(17, 24, 39))
            gravity = Gravity.CENTER_HORIZONTAL
        }
        val title = TextView(this).apply {
            text = "TRADEHUB SCANNER"
            textSize = 26f
            setTextColor(Color.rgb(74, 222, 128))
            gravity = Gravity.CENTER
        }
        info = TextView(this).apply {
            text = "Volatility 25 (1s)\\n5M FVG + Support/Resistance\\n1M rejection confirmation"
            textSize = 16f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            setPadding(0, 28, 0, 28)
        }
        val start = Button(this).apply {
            text = "START BACKGROUND SCANNER"
            setOnClickListener {
                val i = Intent(this@MainActivity, ScannerService::class.java).setAction(ScannerService.ACTION_START)
                if (Build.VERSION.SDK_INT >= 26) startForegroundService(i) else startService(i)
                info.text = "Scanner start requested.\\nLook for the permanent TradeHub notification."
                Toast.makeText(this@MainActivity, "TradeHub Scanner starting", Toast.LENGTH_SHORT).show()
            }
        }
        val stop = Button(this).apply {
            text = "STOP SCANNER"
            setOnClickListener {
                stopService(Intent(this@MainActivity, ScannerService::class.java))
                info.text = "Scanner stopped."
            }
        }
        layout.addView(title)
        layout.addView(info)
        layout.addView(start)
        layout.addView(stop)
        setContentView(layout)
    }

    private fun requestNotificationPermission() {
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 22)
        }
    }
}
