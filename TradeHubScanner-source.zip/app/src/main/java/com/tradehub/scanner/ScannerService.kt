package com.tradehub.scanner

import android.app.*
import android.content.Intent
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import okhttp3.*
import org.json.JSONObject
import org.json.JSONArray
import java.util.concurrent.TimeUnit
import kotlin.math.abs

class ScannerService : Service() {
    companion object {
        const val ACTION_START = "com.tradehub.scanner.START"
        private const val CHANNEL = "tradehub_scanner"
        private const val RUNNING_ID = 1001
        private const val ALERT_ID = 1002
        private const val WS_URL = "wss://api.derivws.com/trading/v1/options/ws/public"
    }

    private val client = OkHttpClient.Builder()
        .readTimeout(0, TimeUnit.MILLISECONDS)
        .pingInterval(20, TimeUnit.SECONDS)
        .build()

    private var socket: WebSocket? = null
    private var reconnectDelay = 3_000L
    private var scanInProgress = false
    private var fiveMinute: List<Candle> = emptyList()
    private var oneMinute: List<Candle> = emptyList()
    private var lastSignalKey = ""
    private val handler = android.os.Handler(android.os.Looper.getMainLooper())
    private var scanRunnable: Runnable? = null
    private var timeoutRunnable: Runnable? = null

    data class Candle(val epoch: Long, val open: Double, val high: Double, val low: Double, val close: Double)
    data class Gap(val direction: String, val bottom: Double, val top: Double, val mid: Double, val formed: Long)

    override fun onCreate() {
        super.onCreate()
        createChannel()
        startForeground(RUNNING_ID, runningNotification("Starting connection to Deriv…"))
        connect()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_START) {
            if (socket == null) connect()
        }
        return START_STICKY
    }

    private fun connect() {
        updateRunning("Connecting to Deriv…")
        socket?.cancel()
        socket = client.newWebSocket(
            Request.Builder().url(WS_URL).build(),
            object : WebSocketListener() {
                override fun onOpen(webSocket: WebSocket, response: Response) {
                    socket = webSocket
                    reconnectDelay = 3_000L
                    updateRunning("Connected · scanning every 30 seconds")
                    scanNow()
                    scheduleNextScan()
                }

                override fun onMessage(webSocket: WebSocket, text: String) {
                    try {
                        val obj = JSONObject(text)
                        if (obj.has("error")) {
                            finishScanWithError(obj.getJSONObject("error").optString("message", "Deriv API error"))
                            return
                        }
                        when (obj.optInt("req_id")) {
                            501 -> fiveMinute = parseCandles(obj.optJSONArray("candles"))
                            502 -> oneMinute = parseCandles(obj.optJSONArray("candles"))
                        }
                        if (fiveMinute.isNotEmpty() && oneMinute.isNotEmpty() && scanInProgress) {
                            scanInProgress = false
                            timeoutRunnable?.let { handler.removeCallbacks(it) }
                            analyse()
                        }
                    } catch (_: Exception) {
                        finishScanWithError("Could not read candle data")
                    }
                }

                override fun onFailure(webSocket: WebSocket, t: Throwable, response: Response?) {
                    socket = null
                    scanInProgress = false
                    updateRunning("Connection lost · reconnecting")
                    handler.postDelayed({ connect() }, reconnectDelay)
                    reconnectDelay = (reconnectDelay * 2).coerceAtMost(60_000L)
                }

                override fun onClosed(webSocket: WebSocket, code: Int, reason: String) {
                    socket = null
                    scanInProgress = false
                    updateRunning("Disconnected · reconnecting")
                    handler.postDelayed({ connect() }, reconnectDelay)
                }
            }
        )
    }

    private fun parseCandles(arr: JSONArray?): List<Candle> {
        if (arr == null) return emptyList()
        val result = mutableListOf<Candle>()
        for (i in 0 until arr.length()) {
            val c = arr.optJSONObject(i) ?: continue
            result.add(Candle(
                c.optLong("epoch"),
                c.optDouble("open"), c.optDouble("high"),
                c.optDouble("low"), c.optDouble("close")
            ))
        }
        return result.sortedBy { it.epoch }
    }

    private fun scanNow() {
        val ws = socket ?: return
        if (ws.send(JSONObject().put("ticks_history", "1HZ25V").put("count", 100)
                .put("end", "latest").put("style", "candles").put("granularity", 300).put("req_id", 501).toString()).not()) return
        fiveMinute = emptyList()
        oneMinute = emptyList()
        scanInProgress = true
        ws.send(JSONObject().put("ticks_history", "1HZ25V").put("count", 100)
            .put("end", "latest").put("style", "candles").put("granularity", 60).put("req_id", 502).toString())
        timeoutRunnable?.let { handler.removeCallbacks(it) }
        timeoutRunnable = Runnable {
            if (scanInProgress) {
                scanInProgress = false
                updateRunning("Candle request timed out · retrying next scan")
            }
        }
        handler.postDelayed(timeoutRunnable!!, 12_000L)
    }

    private fun scheduleNextScan() {
        scanRunnable?.let { handler.removeCallbacks(it) }
        scanRunnable = Runnable {
            if (socket != null) scanNow()
            scheduleNextScan()
        }
        handler.postDelayed(scanRunnable!!, 30_000L)
    }

    private fun finishScanWithError(message: String) {
        scanInProgress = false
        timeoutRunnable?.let { handler.removeCallbacks(it) }
        updateRunning("Scan issue · $message")
    }

    private fun analyse() {
        val now = System.currentTimeMillis() / 1000
        val c5 = fiveMinute.filter { it.epoch + 300 <= now }
        val c1 = oneMinute.filter { it.epoch + 60 <= now }
        if (c5.size < 10 || c1.size < 3) {
            updateRunning("Connected · waiting for closed candles")
            return
        }

        val recent = c5.filter { now - (it.epoch + 300) <= 3600 }
        val gaps = mutableListOf<Gap>()
        for (i in 2 until recent.size) {
            val a = recent[i - 2]
            val c = recent[i]
            if (c.low > a.high) gaps.add(Gap("BUY", a.high, c.low, (a.high + c.low) / 2, c.epoch))
            if (c.high < a.low) gaps.add(Gap("SELL", c.high, a.low, (c.high + a.low) / 2, c.epoch))
        }

        val latest1 = c1.last()
        val support = mutableListOf<Double>()
        val resistance = mutableListOf<Double>()
        for (i in 2 until c5.size - 2) {
            val x = c5[i]
            if (x.low < c5[i-1].low && x.low < c5[i-2].low &&
                x.low < c5[i+1].low && x.low < c5[i+2].low) support.add(x.low)
            if (x.high > c5[i-1].high && x.high > c5[i-2].high &&
                x.high > c5[i+1].high && x.high > c5[i+2].high) resistance.add(x.high)
        }
        val srLevels = support + resistance

        val valid = gaps.asReversed().firstOrNull { g ->
            val after = c5.filter { it.epoch > g.formed }
            val fullyFilled = after.any {
                if (g.direction == "BUY") it.low <= g.bottom else it.high >= g.top
            }
            val midpointTouched = c1.any { it.epoch > g.formed && it.epoch < latest1.epoch &&
                if (g.direction == "BUY") it.low <= g.mid else it.high >= g.mid }
            !fullyFilled && !midpointTouched
        }

        if (valid == null) {
            updateRunning("Connected · no fresh FVG · scanning")
            return
        }

        val g = valid
        val rejection = if (g.direction == "BUY") {
            latest1.low <= g.mid && latest1.close > g.mid && latest1.close > latest1.open
        } else {
            latest1.high >= g.mid && latest1.close < g.mid && latest1.close < latest1.open
        }
        if (!rejection) {
            updateRunning("Connected · fresh ${g.direction} FVG · waiting for 1M rejection")
            return
        }

        val nearSr = srLevels.any { abs(it - g.mid) <= (g.top - g.bottom) * 1.5 }
        val setupType = if (nearSr) "FVG + SUPPORT/RESISTANCE" else "FVG ONLY"
        val key = "${g.direction}-${g.formed}-${latest1.epoch}"
        if (key == lastSignalKey) {
            updateRunning("Connected · signal already notified · scanning")
            return
        }
        lastSignalKey = key

        val entry = g.mid
        val sl = if (g.direction == "BUY") g.bottom else g.top
        val risk = abs(entry - sl)
        if (risk <= 0.0) return
        val tp = if (g.direction == "BUY") entry + 2 * risk else entry - 2 * risk

        sendAlert(
            "TRADEHUB · ${g.direction} SIGNAL",
            "$setupType\\nEntry: ${"%.2f".format(entry)}\\nStop loss: ${"%.2f".format(sl)}\\nTake profit: ${"%.2f".format(tp)}\\nRisk/reward: 1:2"
        )
        updateRunning("Connected · last alert: ${g.direction} · scanning")
    }

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            val channel = NotificationChannel(CHANNEL, "TradeHub Scanner", NotificationManager.IMPORTANCE_DEFAULT)
            channel.description = "Background market scanner status and trade alerts"
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }

    private fun runningNotification(message: String): Notification =
        NotificationCompat.Builder(this, CHANNEL)
            .setSmallIcon(android.R.drawable.ic_menu_search)
            .setContentTitle("TradeHub Scanner Running")
            .setContentText(message)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .build()

    private fun updateRunning(message: String) {
        val nm = getSystemService(NotificationManager::class.java)
        nm.notify(RUNNING_ID, runningNotification(message))
    }

    private fun sendAlert(title: String, body: String) {
        val notification = NotificationCompat.Builder(this, CHANNEL)
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle(title)
            .setContentText(body.replace("\\n", " · "))
            .setStyle(NotificationCompat.BigTextStyle().bigText(body))
            .setAutoCancel(true)
            .build()
        getSystemService(NotificationManager::class.java).notify(ALERT_ID + (System.currentTimeMillis() % 10000).toInt(), notification)
    }

    override fun onDestroy() {
        scanRunnable?.let { handler.removeCallbacks(it) }
        timeoutRunnable?.let { handler.removeCallbacks(it) }
        socket?.close(1000, "Scanner stopped")
        socket = null
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
