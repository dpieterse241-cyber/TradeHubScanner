TRADEHUB SCANNER - ANDROID SOURCE PROJECT
=========================================

This is an early working starter project, not a tested production trading system.
It scans Deriv Volatility 25 (1s) using:
- 5-minute candle history
- 1-minute candle rejection
- Basic 5-minute swing high/low support and resistance proximity
- Android foreground service notification
- Automatic WebSocket reconnect and scan timeout

IMPORTANT LIMITATIONS
---------------------
1. The strategy is experimental. Alerts are not proof of profitability.
2. The support/resistance logic is a simple swing-point approximation and needs backtesting/tuning.
3. FVG freshness and fill rules are simplified and should be validated against your chart.
4. Android may restrict background work. A foreground service is used, but OEM battery controls/network loss can still interrupt it.
5. Do not use alerts as financial advice or place trades without checking the chart and risk.
6. The public Deriv WebSocket endpoint and API message format may change. Confirm the endpoint works before relying on it.

BUILD
-----
The project includes a GitHub Actions workflow at:
.github/workflows/build-apk.yml

Upload this folder to a GitHub repository. The workflow builds a debug APK.
Download the APK from the workflow run's Artifacts section.

On Android:
- Install the APK (allow installation from the browser/files app when prompted).
- Open TradeHub Scanner.
- Allow notifications.
- Press START BACKGROUND SCANNER.
- Keep the persistent notification visible.
- Set battery usage for TradeHub Scanner to Unrestricted if your phone offers that setting.

No account login or trading permission is requested. This app only reads public candle data and sends alerts.
